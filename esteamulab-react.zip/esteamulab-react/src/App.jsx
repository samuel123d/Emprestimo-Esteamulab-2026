import { useState, useEffect, useCallback } from 'react'
import { loadDb, saveDb, SK } from './lib.jsx'
import Auth from './Auth.jsx'
import { Pedir, Meus } from './UserViews.jsx'
import Admin from './AdminViews.jsx'

export default function App() {
  const [db, setDb] = useState(loadDb)
  const [userId, setUserId] = useState(() => sessionStorage.getItem(SK))
  const [view, setView] = useState('pedir')
  const [msg, setMsg] = useState('')

  useEffect(() => saveDb(db), [db])
  // update(fn): copia o estado, aplica a alteração e salva
  const update = useCallback(fn => setDb(p => { const n = structuredClone(p); fn(n); return n }), [])
  const toast = useCallback(m => { setMsg(m); setTimeout(() => setMsg(''), 3500) }, [])

  const user = db.users.find(u => u.id === userId)
  const login = u => { sessionStorage.setItem(SK, u.id); setUserId(u.id); setView('pedir') }
  const sair = () => { sessionStorage.removeItem(SK); setUserId(null) }
  const props = { db, update, toast, user }

  return (
    <>
      <nav className="navbar navbar-dark mb-4">
        <div className="container">
          <span className="navbar-brand fw-semibold">ESTEAMULAB</span>
          {user && (
            <span className="text-white-50 small d-flex align-items-center gap-3">
              <span>{user.nome} ({user.role === 'admin' ? 'administrador' : 'usuário'})</span>
              <button className="btn btn-sm btn-outline-light" onClick={sair}>Sair</button>
            </span>
          )}
        </div>
      </nav>

      <main className="container pb-5" style={{ maxWidth: 960 }}>
        {!user && <Auth {...props} login={login} />}
        {user?.role === 'admin' && <Admin {...props} />}
        {user && user.role !== 'admin' && (
          <>
            <ul className="nav nav-pills mb-4">
              {[['pedir', 'Pedir empréstimo'], ['meus', 'Meus empréstimos']].map(([k, n]) => (
                <li className="nav-item" key={k}>
                  <button className={`nav-link ${view === k ? 'active' : ''}`} onClick={() => setView(k)}>{n}</button>
                </li>
              ))}
            </ul>
            {view === 'pedir' ? <Pedir {...props} /> : <Meus {...props} />}
          </>
        )}
      </main>

      {msg && <div className="toast-box"><div className="toast show text-bg-dark"><div className="toast-body">{msg}</div></div></div>}
    </>
  )
}
