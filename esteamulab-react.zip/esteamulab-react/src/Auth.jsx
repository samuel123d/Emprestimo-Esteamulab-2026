import { useState } from 'react'
import { normContato, hash, novaConta } from './lib.jsx'

export default function Auth({ db, update, toast, login }) {
  const [cad, setCad] = useState(false)
  const [f, setF] = useState({ nome: '', contato: '', senha: '', senha2: '' })
  const set = k => e => setF({ ...f, [k]: e.target.value })
  const setup = !db.users.some(u => u.role === 'admin')

  async function entrar() {
    const u = db.users.find(x => x.contato === normContato(f.contato))
    if (!u || (await hash(f.senha, u.salt)) !== u.hash) return toast('Contato ou senha incorretos.')
    login(u)
  }
  async function criar() {
    if (f.senha !== f.senha2) return toast('As senhas não conferem.')
    try {
      const u = await novaConta(db, f.nome, f.contato, f.senha, setup ? 'admin' : 'user')
      update(d => { d.users.push(u) })
      login(u)
      toast('Conta criada.')
    } catch (e) { toast(typeof e === 'string' ? e : 'Erro ao criar a conta.') }
  }

  return (
    <form className="card shadow-sm mx-auto" style={{ maxWidth: 420 }} onSubmit={e => { e.preventDefault(); cad ? criar() : entrar() }}>
      <div className="card-body">
        <h5 className="mb-3">{cad ? (setup ? 'Criar conta do administrador' : 'Criar conta') : 'Entrar'}</h5>
        {setup && <div className="alert alert-info py-2 small">Nenhum administrador cadastrado ainda. A primeira conta criada será a do administrador.</div>}
        {cad && <>
          <label className="form-label">Nome</label>
          <input className="form-control mb-2" value={f.nome} onChange={set('nome')} autoComplete="name" />
        </>}
        <label className="form-label">WhatsApp ou e-mail</label>
        <input className="form-control mb-2" value={f.contato} onChange={set('contato')} autoComplete="username" />
        <label className="form-label">Senha</label>
        <input type="password" className="form-control mb-2" value={f.senha} onChange={set('senha')} autoComplete={cad ? 'new-password' : 'current-password'} />
        {cad && <>
          <label className="form-label">Confirmar senha</label>
          <input type="password" className="form-control mb-2" value={f.senha2} onChange={set('senha2')} autoComplete="new-password" />
        </>}
        <button className="btn btn-dark w-100 mt-2">{cad ? 'Criar conta' : 'Entrar'}</button>
        <div className="text-center mt-3 small">
          {cad ? 'Já tem conta? ' : 'Ainda não tem conta? '}
          <a href="#" onClick={e => { e.preventDefault(); setCad(!cad) }}>{cad ? 'Entrar' : 'Criar conta'}</a>
        </div>
      </div>
    </form>
  )
}
