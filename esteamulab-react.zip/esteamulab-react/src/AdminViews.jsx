import { useState, useEffect } from 'react'
import { today, fmt, ativo, itemLivre, itemNome, uid, hash, novaConta, lembretes, quando, linkContato, Status } from './lib.jsx'

export default function Admin(props) {
  const [tab, setTab] = useState('painel')
  const [, tick] = useState(0)

  // reavalia os lembretes a cada minuto
  useEffect(() => { const t = setInterval(() => tick(n => n + 1), 60000); return () => clearInterval(t) }, [])
  // notificação do navegador (uma vez por dia)
  useEffect(() => {
    const n = lembretes(props.db), k = 'avisado_' + today()
    if (n.length && 'Notification' in window && Notification.permission === 'granted' && !sessionStorage.getItem(k)) {
      sessionStorage.setItem(k, '1')
      new Notification('ESTEAMULAB', { body: `${n.length} devolução(ões) próxima(s) ou atrasada(s).` })
    }
  }, []) // eslint-disable-line

  const tabs = { painel: ['Painel', Painel], produtos: ['Produtos', Produtos], usuarios: ['Usuários', Usuarios], config: ['Configurações', Config] }
  const View = tabs[tab][1]
  return (
    <>
      <ul className="nav nav-tabs mb-3">
        {Object.entries(tabs).map(([k, [n]]) => (
          <li className="nav-item" key={k}><button className={`nav-link ${tab === k ? 'active' : ''}`} onClick={() => setTab(k)}>{n}</button></li>
        ))}
      </ul>
      <View {...props} />
    </>
  )
}

function Painel({ db, update, toast }) {
  const [cod, setCod] = useState('')
  const lem = lembretes(db)

  function validar() {
    const l = db.loans.find(x => x.codigo === cod.trim().toUpperCase() && ativo(x))
    if (!l) return toast('Código não encontrado ou já finalizado.')
    const nome = itemNome(db, l.itemId)
    update(d => {
      const x = d.loans.find(y => y.id === l.id)
      if (x.status === 'reservado') { x.status = 'emprestado'; x.retirado = today() }
      else { x.status = 'devolvido'; x.devolvidoEm = today() }
    })
    toast(l.status === 'reservado' ? `Retirada confirmada: ${nome} com ${l.nome}.` : `Devolução confirmada: ${nome}.`)
    setCod('')
  }
  const cancelar = id => update(d => { d.loans.find(x => x.id === id).status = 'cancelado' })

  return (
    <>
      {lem.length > 0 && (
        <div className="alert alert-warning">
          <strong>Lembretes de devolução ({lem.length})</strong>
          {lem.map(l => (
            <div key={l.id} className="d-flex justify-content-between align-items-center mt-2 flex-wrap gap-2">
              <span>{l.nome} · {itemNome(db, l.itemId)} · {quando(l.dias)}</span>
              <a className="btn btn-sm btn-dark" target="_blank" rel="noopener noreferrer" href={linkContato(db, l)}>
                Avisar {l.contato.includes('@') ? 'por e-mail' : 'no WhatsApp'}
              </a>
            </div>
          ))}
        </div>
      )}
      <form className="card shadow-sm mb-3" onSubmit={e => { e.preventDefault(); validar() }}><div className="card-body">
        <h6>Validar código (retirada ou devolução)</h6>
        <div className="input-group">
          <input className="form-control text-uppercase" maxLength={6} placeholder="Código do usuário" value={cod} onChange={e => setCod(e.target.value)} />
          <button className="btn btn-dark">Validar</button>
        </div>
      </div></form>
      <div className="card shadow-sm"><div className="card-body">
        <h6>Empréstimos</h6>
        <div className="table-responsive"><table className="table align-middle mb-0">
          <thead><tr><th>Produto</th><th>Usuário</th><th>Devolução</th><th>Código</th><th>Status</th><th /></tr></thead>
          <tbody>
            {db.loans.length === 0 && <tr><td colSpan={6} className="text-muted">Nenhum empréstimo ainda.</td></tr>}
            {[...db.loans].reverse().map(l => (
              <tr key={l.id}>
                <td>{itemNome(db, l.itemId)}</td>
                <td>{l.nome}<div className="small text-muted">{l.contato}</div></td>
                <td>{fmt(l.devolucao)}</td>
                <td className="fw-bold">{l.codigo}</td>
                <td><Status s={l.status} /></td>
                <td className="text-end">{l.status === 'reservado' && <button className="btn btn-sm btn-outline-secondary" onClick={() => cancelar(l.id)}>Cancelar</button>}</td>
              </tr>
            ))}
          </tbody>
        </table></div>
      </div></div>
    </>
  )
}

function Produtos({ db, update, toast }) {
  const [nome, setNome] = useState('')
  const [desc, setDesc] = useState('')
  function add(e) {
    e.preventDefault()
    if (!nome.trim()) return toast('Informe o nome do produto.')
    update(d => { d.items.push({ id: uid(), nome: nome.trim(), desc: desc.trim() }) })
    setNome(''); setDesc('')
  }
  function del(id) {
    if (!itemLivre(db, id)) return toast('Este produto tem empréstimo em andamento.')
    if (confirm('Remover este produto?')) update(d => { d.items = d.items.filter(i => i.id !== id) })
  }
  return (
    <>
      <form className="card shadow-sm mb-3" onSubmit={add}><div className="card-body">
        <h6>Cadastrar produto</h6>
        <div className="row g-2">
          <div className="col-md-4"><input className="form-control" placeholder="Nome" value={nome} onChange={e => setNome(e.target.value)} /></div>
          <div className="col-md-6"><input className="form-control" placeholder="Descrição (opcional)" value={desc} onChange={e => setDesc(e.target.value)} /></div>
          <div className="col-md-2"><button className="btn btn-dark w-100">Adicionar</button></div>
        </div>
      </div></form>
      <div className="card shadow-sm"><ul className="list-group list-group-flush">
        {db.items.length === 0 && <li className="list-group-item text-muted">Nenhum produto cadastrado.</li>}
        {db.items.map(i => (
          <li key={i.id} className="list-group-item d-flex justify-content-between align-items-center">
            <span><strong>{i.nome}</strong> <span className="text-muted small">{i.desc}</span></span>
            <span>
              <span className={`badge me-2 text-bg-${itemLivre(db, i.id) ? 'success' : 'secondary'}`}>{itemLivre(db, i.id) ? 'Disponível' : 'Emprestado'}</span>
              <button className="btn btn-sm btn-outline-danger" onClick={() => del(i.id)}>Remover</button>
            </span>
          </li>
        ))}
      </ul></div>
    </>
  )
}

function Usuarios({ db, update, toast, user }) {
  const [f, setF] = useState({ nome: '', contato: '', senha: '' })
  const set = k => e => setF({ ...f, [k]: e.target.value })

  async function addAdmin(e) {
    e.preventDefault()
    try {
      const u = await novaConta(db, f.nome, f.contato, f.senha, 'admin')
      update(d => { d.users.push(u) })
      setF({ nome: '', contato: '', senha: '' }); toast('Administrador cadastrado.')
    } catch (err) { toast(typeof err === 'string' ? err : 'Erro ao cadastrar.') }
  }
  const toggle = id => update(d => { const u = d.users.find(x => x.id === id); u.role = u.role === 'admin' ? 'user' : 'admin' })
  async function reset(u) {
    const s = prompt(`Nova senha para ${u.nome} (mínimo 6 caracteres):`)
    if (s === null) return
    if (s.length < 6) return toast('A senha precisa ter ao menos 6 caracteres.')
    const salt = uid() + uid(), h = await hash(s, salt)
    update(d => { const x = d.users.find(y => y.id === u.id); x.salt = salt; x.hash = h })
    toast('Senha redefinida.')
  }
  function del(u) {
    if (db.loans.some(l => l.userId === u.id && ativo(l))) return toast('Este usuário tem empréstimo em andamento.')
    if (confirm(`Excluir a conta de ${u.nome}?`)) update(d => { d.users = d.users.filter(x => x.id !== u.id) })
  }

  return (
    <>
      <form className="card shadow-sm mb-3" onSubmit={addAdmin}><div className="card-body">
        <h6>Cadastrar novo administrador</h6>
        <div className="row g-2">
          <div className="col-md-3"><input className="form-control" placeholder="Nome" value={f.nome} onChange={set('nome')} /></div>
          <div className="col-md-3"><input className="form-control" placeholder="WhatsApp ou e-mail" value={f.contato} onChange={set('contato')} /></div>
          <div className="col-md-3"><input type="password" className="form-control" placeholder="Senha inicial" value={f.senha} onChange={set('senha')} autoComplete="new-password" /></div>
          <div className="col-md-3"><button className="btn btn-dark w-100">Cadastrar</button></div>
        </div>
      </div></form>
      <div className="card shadow-sm"><div className="card-body">
        <h6>Contas ({db.users.length})</h6>
        <div className="table-responsive"><table className="table align-middle mb-0">
          <thead><tr><th>Nome</th><th>Contato</th><th>Perfil</th><th /></tr></thead>
          <tbody>
            {db.users.map(u => (
              <tr key={u.id}>
                <td>{u.nome}{u.id === user.id && <span className="text-muted small"> (você)</span>}</td>
                <td>{u.contato}</td>
                <td><span className={`badge text-bg-${u.role === 'admin' ? 'dark' : 'secondary'}`}>{u.role === 'admin' ? 'administrador' : 'usuário'}</span></td>
                <td className="text-end text-nowrap">{u.id !== user.id && <>
                  <button className="btn btn-sm btn-outline-secondary me-1" onClick={() => toggle(u.id)}>{u.role === 'admin' ? 'Tornar usuário' : 'Tornar admin'}</button>
                  <button className="btn btn-sm btn-outline-secondary me-1" onClick={() => reset(u)}>Redefinir senha</button>
                  <button className="btn btn-sm btn-outline-danger" onClick={() => del(u)}>Excluir</button>
                </>}</td>
              </tr>
            ))}
          </tbody>
        </table></div>
      </div></div>
    </>
  )
}

function Config({ db, update, toast, user }) {
  const [dias, setDias] = useState(db.cfg.diasAviso)
  const [max, setMax] = useState(db.cfg.maxDias)
  const [senha, setSenha] = useState('')
  const [perm, setPerm] = useState('Notification' in window ? Notification.permission : 'indisponível')

  async function salvar() {
    const d = parseInt(dias), m = parseInt(max)
    if (isNaN(d) || d < 0 || isNaN(m) || m < 1) return toast('Valores inválidos.')
    if (senha && senha.length < 6) return toast('A senha precisa ter ao menos 6 caracteres.')
    const salt = uid() + uid(), h = senha ? await hash(senha, salt) : null
    update(x => {
      x.cfg.diasAviso = d; x.cfg.maxDias = m
      if (h) { const u = x.users.find(y => y.id === user.id); u.salt = salt; u.hash = h }
    })
    setSenha(''); toast('Configurações salvas.')
  }

  return (
    <div className="card shadow-sm"><div className="card-body">
      <div className="row g-3">
        <div className="col-md-4"><label className="form-label">Avisar quantos dias antes da devolução</label>
          <input type="number" min="0" max="30" className="form-control" value={dias} onChange={e => setDias(e.target.value)} /></div>
        <div className="col-md-4"><label className="form-label">Prazo máximo de empréstimo (dias)</label>
          <input type="number" min="1" max="365" className="form-control" value={max} onChange={e => setMax(e.target.value)} /></div>
        <div className="col-md-4"><label className="form-label">Alterar minha senha</label>
          <input type="password" className="form-control" placeholder="Deixe vazio para manter" value={senha} onChange={e => setSenha(e.target.value)} autoComplete="new-password" /></div>
      </div>
      <button className="btn btn-dark mt-3" onClick={salvar}>Salvar configurações</button>
      <hr />
      <div className="d-flex align-items-center gap-3 flex-wrap">
        <span>Notificação do navegador: <strong>{perm}</strong></span>
        {'Notification' in window && <button className="btn btn-sm btn-outline-secondary" onClick={() => Notification.requestPermission().then(setPerm)}>Ativar notificações</button>}
      </div>
    </div></div>
  )
}
