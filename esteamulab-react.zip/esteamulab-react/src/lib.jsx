// Utilitários, dados e regras do sistema (mesma chave do localStorage da versão HTML)
export const KEY = 'esteamulab_emprestimos'
export const SK = 'esteamulab_sessao'

export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6)
export const ymd = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
export const today = () => ymd(new Date())
export const addDays = n => { const d = new Date(); d.setDate(d.getDate() + n); return ymd(d) }
export const diff = d => Math.round((new Date(d + 'T00:00') - new Date(today() + 'T00:00')) / 864e5)
export const fmt = d => (d ? d.split('-').reverse().join('/') : '')

export function loadDb() {
  let d = {}
  try { d = JSON.parse(localStorage.getItem(KEY)) || {} } catch { /* base vazia */ }
  const cfg = { diasAviso: 1, maxDias: 30, ...(d.cfg || {}) }
  delete cfg.pin
  return { items: d.items || [], loans: d.loans || [], users: d.users || [], cfg }
}
export const saveDb = db => { try { localStorage.setItem(KEY, JSON.stringify(db)) } catch { /* sem espaço */ } }

export const ativo = l => l.status === 'reservado' || l.status === 'emprestado'
export const itemLivre = (db, id) => !db.loans.some(l => l.itemId === id && ativo(l))
export const itemNome = (db, id) => db.items.find(i => i.id === id)?.nome ?? '(removido)'
export function gerarCodigo(db) {
  const a = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  let c
  do { c = Array.from({ length: 6 }, () => a[Math.floor(Math.random() * a.length)]).join('') }
  while (db.loans.some(l => l.codigo === c))
  return c
}

/* ---- Contas ---- */
export const normContato = c => { c = c.trim(); return c.includes('@') ? c.toLowerCase() : c.replace(/\D/g, '') }
export const contatoOk = c => (c.includes('@') ? /^\S+@\S+\.\S+$/.test(c) : c.length >= 10)
export async function hash(s, salt) {
  const t = salt + s
  if (window.crypto?.subtle) {
    const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(t))
    return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('')
  }
  let h = 5381
  for (const ch of t) h = ((h << 5) + h + ch.charCodeAt(0)) >>> 0
  return 'x' + h
}
// Valida e devolve a nova conta (lança string com a mensagem de erro)
export async function novaConta(db, nome, contato, senha, role) {
  const c = normContato(contato)
  if (!nome.trim()) throw 'Informe o nome.'
  if (!contatoOk(c)) throw 'Informe um e-mail válido ou um WhatsApp com DDD.'
  if (senha.length < 6) throw 'A senha precisa ter ao menos 6 caracteres.'
  if (db.users.some(u => u.contato === c)) throw 'Já existe uma conta com este contato.'
  const salt = uid() + uid()
  return { id: uid(), nome: nome.trim(), contato: c, salt, hash: await hash(senha, salt), role, criado: today() }
}

/* ---- Lembretes ---- */
export const lembretes = db =>
  db.loans.filter(l => l.status === 'emprestado' && diff(l.devolucao) <= db.cfg.diasAviso).map(l => ({ ...l, dias: diff(l.devolucao) }))
export const quando = d => (d < 0 ? `atrasado há ${-d} dia(s)` : d === 0 ? 'vence hoje' : d === 1 ? 'vence amanhã' : `vence em ${d} dias`)
export function linkContato(db, l) {
  const msg = `Olá, ${l.nome}! Lembrete do ESTEAMULAB: a devolução de "${itemNome(db, l.itemId)}" ${quando(l.dias ?? diff(l.devolucao))} (${fmt(l.devolucao)}). Código de devolução: ${l.codigo}.`
  const m = encodeURIComponent(msg)
  if (l.contato.includes('@')) return `mailto:${l.contato}?subject=${encodeURIComponent('Lembrete de devolução - ESTEAMULAB')}&body=${m}`
  let n = l.contato.replace(/\D/g, '')
  if (n.length <= 11) n = '55' + n
  return `https://wa.me/${n}?text=${m}`
}

/* ---- UI compartilhada ---- */
const cls = { reservado: 'warning text-dark', emprestado: 'primary', devolvido: 'success', cancelado: 'secondary' }
export const Status = ({ s }) => <span className={`badge text-bg-${cls[s]}`}>{s}</span>
